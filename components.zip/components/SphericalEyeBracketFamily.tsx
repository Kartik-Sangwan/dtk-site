"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { sphericalEyeBrackets } from "@/lib/sphericalEyeBracket";

function TipTh({ label, tip }: { label: string; tip: string }) {
  return (
    <th className="px-4 py-3 font-semibold text-gray-900">
      <div className="group relative inline-block cursor-help">
        {label}
        <div className="pointer-events-none absolute left-1/2 top-full z-50 mt-2 w-max -translate-x-1/2 rounded-md bg-gray-900 px-2 py-1 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100">
          {tip}
        </div>
      </div>
    </th>
  );
}

export default function SphericalEyeBracketFamily() {
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return sphericalEyeBrackets;
    return sphericalEyeBrackets.filter((r) =>
      r.part.toLowerCase().includes(s)
    );
  }, [q]);

  return (
    <section className="w-full">
      {/* Top card */}
      <div className="rounded-2xl border border-slate-200/70 bg-white/70 p-6 shadow-sm backdrop-blur">
        <div className="grid gap-8 md:grid-cols-[1.2fr_1fr] md:items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Spherical Eye Bracket
            </h1>
            <p className="mt-3 text-gray-700">
              NFPA spherical eye brackets. Search by part number to view
              dimensions.
            </p>

            <div className="mt-6">
              <label className="text-sm font-semibold text-gray-900">
                Search part number
              </label>
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder='Try "DS-10"'
                className="mt-2 w-full rounded-md border border-slate-300 bg-white px-3 py-2 outline-none focus:border-slate-500"
              />
            </div>

            <div className="mt-4 text-sm text-gray-600">
              Showing{" "}
              <span className="font-semibold text-gray-900">
                {rows.length}
              </span>{" "}
              parts
            </div>
          </div>

          {/* Diagram */}
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl bg-white">
              <Image
                src="/products/spherical-eye-bracket.png"
                alt="Spherical Eye Bracket"
                fill
                className="object-contain p-6"
              />
            </div>

            <div className="mt-3 flex items-center justify-between">
              <div className="text-sm font-semibold text-gray-900">
                Material: Cast iron
              </div>
              <a
                href="/specs/spherical-eye-bracket-diagram.png"
                target="_blank"
                className="text-sm font-semibold underline"
              >
                Open spec sheet
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="mt-8 overflow-hidden rounded-2xl border border-slate-200/70 bg-white/70 shadow-sm backdrop-blur">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/90">
              <tr className="border-b">
                <th className="px-4 py-3 font-semibold">Part #</th>
                <TipTh label="CB" tip="Center bore width" />
                <TipTh label="CD" tip="Pin hole diameter" />
                <TipTh label="DD" tip="Mount hole diameter" />
                <TipTh label="E" tip="Overall base length" />
                <TipTh label="F" tip="Base thickness" />
                <TipTh label="FL" tip="Flange length" />
                <TipTh label="LR" tip="Left radius" />
                <TipTh label="M" tip="Mount height" />
                <TipTh label="MR" tip="Mount radius" />
                <TipTh label="R" tip="Base radius" />
              </tr>
            </thead>

            <tbody>
              {rows.map((r) => (
                <tr key={r.part} className="border-b hover:bg-slate-50/60">
                  <td className="px-4 py-3 font-semibold">{r.part}</td>
                  <td className="px-4 py-3">{r.CB}</td>
                  <td className="px-4 py-3">{r.CD}</td>
                  <td className="px-4 py-3">{r.DD}</td>
                  <td className="px-4 py-3">{r.E}</td>
                  <td className="px-4 py-3">{r.F}</td>
                  <td className="px-4 py-3">{r.FL}</td>
                  <td className="px-4 py-3">{r.LR}</td>
                  <td className="px-4 py-3">{r.M}</td>
                  <td className="px-4 py-3">{r.MR}</td>
                  <td className="px-4 py-3">{r.R}</td>
                </tr>
              ))}

              {rows.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-4 py-10 text-center text-gray-600">
                    No parts found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Legend */}
        <div className="mt-4 rounded-xl border bg-slate-50 p-4">
          <div className="text-sm font-semibold">Dimension Legend</div>
          <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-3">
            <div><strong>CB</strong> — Center bore width</div>
            <div><strong>CD</strong> — Pin hole diameter</div>
            <div><strong>DD</strong> — Mount hole diameter</div>
            <div><strong>E</strong> — Overall base length</div>
            <div><strong>F</strong> — Base thickness</div>
            <div><strong>FL</strong> — Flange length</div>
            <div><strong>LR</strong> — Left radius</div>
            <div><strong>M</strong> — Mount height</div>
            <div><strong>MR</strong> — Mount radius</div>
            <div><strong>R</strong> — Base radius</div>
          </div>
        </div>
      </div>
    </section>
  );
}
